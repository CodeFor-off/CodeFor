<?php
/**
 * Plugin Name: Codefor-Tech Chat AI
 * Plugin URI: https://codefor.tech/
 * Description: Плагин интеграции AI-бота для WordPress. Автоматически добавляет чат-виджет на сайт.
 * Version: 1.1
 * Author: Парипа Максим
 * Author URI: https://codefor.tech/
 * Text Domain: codefor-tech
 * Domain Path: /languages
 */

if (!defined('ABSPATH')) {
    exit; // Запрет прямого доступа
}

// Загрузка текстового домена для перевода
function codefor_tech_load_textdomain() {
    load_plugin_textdomain('codefor-tech', false, dirname(plugin_basename(__FILE__)) . '/languages');
}
add_action('plugins_loaded', 'codefor_tech_load_textdomain');

// Подключаем стили и скрипты
function codefor_tech_enqueue_assets() {
    wp_enqueue_style('codefor-tech-style', plugin_dir_url(__FILE__) . 'assets/codefor-tech-style.css');
    wp_enqueue_script('codefor-tech-script', plugin_dir_url(__FILE__) . 'assets/codefor-tech-script.js', array('jquery'), null, true);

    // Передаем AJAX URL в JS
    wp_localize_script('codefor-tech-script', 'codeforTechAjax', array(
        'ajaxurl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('codefor-tech-nonce'),
        'button_style' => esc_attr__('right: -79px;', 'codefor-tech')
    ));
}
add_action('wp_enqueue_scripts', 'codefor_tech_enqueue_assets');

// Добавляем HTML-код чата в footer
function codefor_tech_add_chat_widget() {
    ?>
    <button id="codefor-tech-chat-toggle" class="codefor-tech-chat-toggle" style="<?php echo esc_attr__('right: -79px;', 'codefor-tech'); ?>">
        <?php _e('Вызвать<br>Искусственный интеллект', 'codefor-tech'); ?>
    </button>
    <div class="codefor-tech-chat-container" id="codefor-tech-chat-container">
        <h2 class="codefor-tech-title"><?php _e('Codefor-Tech Чат', 'codefor-tech'); ?></h2>
        <div class="codefor-tech-chat-box" id="codefor-tech-chat-box">
            <div class="codefor-tech-message codefor-tech-bot">
                <?php _e('Привет! Я AI-бот. Чем могу помочь?', 'codefor-tech'); ?>
            </div>
        </div>
        <form id="codefor-tech-chat-form" class="codefor-tech-chat-form">
            <input type="text" id="codefor-tech-user-input" class="codefor-tech-input" 
                   placeholder="<?php esc_attr_e('Введите сообщение...', 'codefor-tech'); ?>" required>
            <button type="submit" class="codefor-tech-button">
                <?php _e('Отправить', 'codefor-tech'); ?>
            </button>
        </form>
    </div>
    <?php
}
add_action('wp_footer', 'codefor_tech_add_chat_widget');

// AJAX обработчик запроса к AI
function codefor_tech_handle_chat_request() {
    check_ajax_referer('codefor-tech-nonce', 'nonce');

    $user_message = sanitize_text_field($_POST['message']);
    $api_url = "https://api.deepinfra.com/v1/openai/chat/completions";
    $api_key = "ZCdDKuKfxf0CDNqvYMzmVPsgCurPOk3l"; // Укажите свой API-ключ

    $data = [
        "model" => "mistralai/Mistral-7B-Instruct-v0.1",
        "messages" => [["role" => "user", "content" => $user_message]],
        "temperature" => 0.7
    ];

    $response = wp_remote_post($api_url, [
        'headers' => [
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $api_key
        ],
        'body' => json_encode($data),
        'timeout' => 30
    ]);

    if (is_wp_error($response)) {
        echo esc_html__('Ошибка API', 'codefor-tech');
    } else {
        $body = wp_remote_retrieve_body($response);
        $response_data = json_decode($body, true);
        echo nl2br(esc_html($response_data["choices"][0]["message"]["content"] ?? esc_html__('Ошибка', 'codefor-tech')));
    }

    wp_die();
}
add_action('wp_ajax_codefor_tech_chat', 'codefor_tech_handle_chat_request');
add_action('wp_ajax_nopriv_codefor_tech_chat', 'codefor_tech_handle_chat_request');

jQuery(document).ready(function ($) {
    $("#codefor-tech-chat-form").submit(function (event) {
        event.preventDefault();

        let userInput = $("#codefor-tech-user-input").val();
        if (!userInput.trim()) return;

        let chatBox = $("#codefor-tech-chat-box");
        chatBox.append(`<div class="codefor-tech-message codefor-tech-user">${userInput}</div>`);
        $("#codefor-tech-user-input").val("");

        $.post(codeforTechAjax.ajaxurl, {
            action: "codefor_tech_chat",
            nonce: codeforTechAjax.nonce,
            message: userInput
        }, function (response) {
            chatBox.append(`<div class="codefor-tech-message codefor-tech-bot">${response}</div>`);
            chatBox.scrollTop(chatBox[0].scrollHeight);
        });
    });

    $("#codefor-tech-chat-toggle").click(function () {
        $("#codefor-tech-chat-container").toggleClass("codefor-tech-open");
    });
});
